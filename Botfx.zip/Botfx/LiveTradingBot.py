import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
import pytz
import time

from MT5DataFetcher import MT5DataFetcher
from CandlestickPatternIdentifier import CandlestickPatternIdentifier
from IndicatorCalculator import IndicatorCalculator
from TradingSignals import TradingSignals
from MLModel import MLModel

class LiveTradingBot:
    def __init__(self, symbol, timeframe, model):
        self.symbol = symbol
        self.timeframe = timeframe
        self.model = model
        self.fetcher = MT5DataFetcher(timezone='Asia/Karachi')
        self.indicator_calculator = None
        self.candlestick_identifier = CandlestickPatternIdentifier()
        self.df = None
        self.currentBars = None

    def fetch_and_prepare_data(self):
        self.currentBars = self.fetcher.get_live_data(self.symbol, self.timeframe, 51)
        if self.currentBars is not None:
            self.indicator_calculator = IndicatorCalculator(self.currentBars)
            self.indicator_calculator.calculate_ema(50)
            self.indicator_calculator.calculate_volume_ma(20)
            self.indicator_calculator.calculate_rsi(14)
            self.indicator_calculator.check_ema()
            self.indicator_calculator.check_volume()
            self.indicator_calculator.check_rsi()
            self.currentBars = self.candlestick_identifier.add_candlestick_column(self.currentBars)
            trading_bot = TradingSignals(self.currentBars)
            trading_bot.calculate_signals()
            self.currentBars['emaCheck'] = self.currentBars['emaCheck'].map({'above': 1, 'below': 0})
            self.currentBars['rsiCheck'] = self.currentBars['rsiCheck'].map({'above': 1, 'below': 0})
            self.currentBars['volumeCheck'] = self.currentBars['volumeCheck'].map({'above': 1, 'below': 0})
            self.currentBars['candlestick_type'] = self.currentBars['candlestick_type'].astype('category').cat.codes

    def make_decision(self):
        if self.currentBars is not None:
            currentInstance = self.currentBars.iloc[-2]       
            if(currentInstance['signal']!=0):
                X = currentInstance[['emaCheck', 'rsiCheck', 'volumeCheck', 'signal', 'candlestick_type']]
                return self.model.predict_single_instance(X),X['signal']
        return 0,0
    
    # function to send a market order
    def market_order(symbol, volume, order_type, **kwargs):
        tick = mt5.symbol_info_tick(symbol)

        order_dict = {'buy': 0, 'sell': 1}
        price_dict = {'buy': tick.ask, 'sell': tick.bid}

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_dict[order_type],
            "price": price_dict[order_type],
            "deviation": DEVIATION,
            "magic": 100,
            "comment": "python market order",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        order_result = mt5.order_send(request)
        print(order_result)

        return order_result

    def shutdown(self):
        self.fetcher.shutdown()

# Example usage:
if __name__ == "__main__":
    # strategy parameters
    SYMBOL = "XAUUSDm"
    VOLUME = 0.01
    TIMEFRAME = mt5.TIMEFRAME_M5
    EMA_PERIOD = 50
    DEVIATION = 20
    BOT_UPTIME = 0
    timeframe = mt5.TIMEFRAME_M5
    start_date = datetime(2024, 2, 1, 12, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))
    end_date = datetime(2024, 5, 31, 15, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))

    fetcher = MT5DataFetcher(timezone='Asia/Karachi')
    df = fetcher.get_data(SYMBOL, timeframe, start_date, end_date)

    if df is not None:
        indicator_calculator = IndicatorCalculator(df)
        indicator_calculator.calculate_ema(EMA_PERIOD)
        indicator_calculator.calculate_volume_ma(20)
        indicator_calculator.calculate_rsi(14)
        indicator_calculator.check_ema()
        indicator_calculator.check_volume()
        indicator_calculator.check_rsi()

        candlestick_identifier = CandlestickPatternIdentifier()
        df = candlestick_identifier.add_candlestick_column(df)

        trading_bot = TradingSignals(df)
        trading_bot.calculate_signals()
        trading_bot.evaluate_trades()

        ml_model = MLModel(df)
        ml_model.train_model()
        
        live_trading_bot = LiveTradingBot(SYMBOL, timeframe, ml_model)
        live_trading_bot.fetch_and_prepare_data()
        
        while True:
            print("Bot uptime: " + str(BOT_UPTIME)+" Minutes")
            live_trading_bot.fetch_and_prepare_data()
            decision, actual_signal = live_trading_bot.make_decision()
            if decision == 1:
                if actual_signal == 1:
                    live_trading_bot.market_order(SYMBOL, VOLUME, 'sell')
                    print("Current Decision : Sell")
                elif actual_signal == 2:
                    live_trading_bot.market_order(SYMBOL, VOLUME, 'buy')
                    print("Current Decision : Buy:)
            else:
                print("Current Decision : No trade)
                      
            # Wait for 1 minute
            BOT_UPTIME = BOT_UPTIME + 1
            time.sleep(60)

    fetcher.shutdown()
