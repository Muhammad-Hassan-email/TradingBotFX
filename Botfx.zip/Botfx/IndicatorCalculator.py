import pandas_ta as ta

class IndicatorCalculator:
    def __init__(self, df):
        self.df = df

    def calculate_ema(self, period):
        self.df[f'{period}ema'] = self.df['close'].ewm(span=period, adjust=False).mean()

    def calculate_volume_ma(self, period):
        if 'tick_volume' not in self.df.columns:
            raise ValueError("DataFrame must contain a 'tick_volume' column")
        self.df['volume_ma'] = self.df['tick_volume'].rolling(window=period).mean()
        
    def calculate_rsi(self,period):
        self.df['RSI'] = self.df.ta.rsi(length=14)

    def check_ema(self):
        self.df['emaCheck'] = ['above' if close > ema else 'below' for close, ema in zip(self.df['close'], self.df['50ema'])]

    def check_volume(self):
        self.df['volumeCheck'] = ['above' if volume > ma else 'below' for volume, ma in zip(self.df['tick_volume'], self.df['volume_ma'])]
        
    def check_rsi(self):
        self.df['rsiCheck'] = ['above' if rsi > 50 else 'below' for rsi in self.df['RSI']]
