from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import pandas as pd

class MLModel:
    def __init__(self, df):
        self.df = df

    def preprocess_data(self):
        filtered_df = self.df[self.df['signal'].isin([1, 2])]    
        # Select the specified columns
        self.df = filtered_df[['emaCheck', 'rsiCheck', 'volumeCheck', 'signal','candlestick_type','trade_result']]
        self.df['emaCheck'] = self.df['emaCheck'].map({'above': 1, 'below': 0})
        self.df['rsiCheck'] = self.df['rsiCheck'].map({'above': 1, 'below': 0})
        self.df['volumeCheck'] = self.df['volumeCheck'].map({'above': 1, 'below': 0})
        self.df['candlestick_type'] = self.df['candlestick_type'].astype('category').cat.codes
        self.df['trade_result'] = self.df['trade_result'].map({'profit': 1, 'loss': 0})
        self.df.dropna(subset=['trade_result'], inplace=True)
        

    def train_model(self):
        self.preprocess_data()
        X = self.df[['emaCheck', 'rsiCheck', 'volumeCheck', 'signal', 'candlestick_type']]
        y = self.df['trade_result']

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        self.clf = DecisionTreeClassifier(random_state=42)
        self.clf.fit(X_train, y_train)

        y_pred = self.clf.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print(f'Accuracy: {accuracy:.2f}')

        print('Classification Report:')
        print(classification_report(y_test, y_pred))

        self.df['predicted_trade_result'] = self.clf.predict(X)
        return self.df

    def predict(self, X):
        return self.clf.predict(X)
    
    def predict_single_instance(self, instance):
        """
        Predicts the trade result for a single instance.

        Parameters:
        - instance (pd.Series or dict): The instance to predict, containing features like 'emaCheck', 'rsiCheck', etc.

        Returns:
        - int: The predicted trade result (1 for profit, 0 for loss).
        """
        if self.clf is None:
            raise ValueError("Model not trained. Call train_model() first.")

        # Convert the instance to DataFrame if it's a dictionary
        if isinstance(instance, dict):
            instance = pd.DataFrame([instance])

        # Extract features for prediction
        X_instance = instance[['emaCheck', 'rsiCheck', 'volumeCheck', 'signal', 'candlestick_type']]
        X_instance = X_instance.values.reshape(1,-1)
        # Make prediction for the instance
        prediction = self.clf.predict(X_instance)

        # Return the predicted trade result
        return prediction[0]
