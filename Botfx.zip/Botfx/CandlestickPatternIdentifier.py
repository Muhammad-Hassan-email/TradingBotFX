class CandlestickPatternIdentifier:
    @staticmethod
    def identify_candlestick(row, previous_row=None, two_previous_row=None):
        open_price = row['open']
        high_price = row['high']
        low_price = row['low']
        close_price = row['close']
        
        body_size = abs(close_price - open_price)
        upper_shadow = high_price - max(open_price, close_price)
        lower_shadow = min(open_price, close_price) - low_price
        
        doji_threshold = 0.1 * (high_price - low_price)
        shadow_threshold = 2 * body_size
        
        if body_size <= doji_threshold:
            return 'doji'
        if body_size < (high_price - low_price) / 3 and lower_shadow > shadow_threshold and upper_shadow < body_size:
            return 'hammer'
        if body_size < (high_price - low_price) / 3 and upper_shadow > shadow_threshold and lower_shadow < body_size:
            return 'shooting star'
        
        if previous_row is not None:
            prev_open = previous_row['open']
            prev_close = previous_row['close']
            if prev_close < prev_open and close_price > open_price and close_price > prev_open and open_price < prev_close:
                return 'bullish engulfing'
            if prev_close > prev_open and close_price < open_price and open_price > prev_close and close_price < prev_open:
                return 'bearish engulfing'
        
        if previous_row is not None and two_previous_row is not None:
            prev_open = previous_row['open']
            prev_close = previous_row['close']
            two_prev_open = two_previous_row['open']
            two_prev_close = two_previous_row['close']
            if two_prev_close < two_prev_open and prev_close < prev_open and close_price > open_price and prev_close < two_prev_close and close_price > (two_prev_close + two_prev_open) / 2:
                return 'morning star'
            if two_prev_close > two_prev_open and prev_close > prev_open and close_price < open_price and prev_close > two_prev_close and close_price < (two_prev_close + two_prev_open) / 2:
                return 'evening star'
        
        return 'normal'

    def add_candlestick_column(self, df):
        candlestick_types = []
        for i in range(len(df)):
            if i >= 2:
                pattern = self.identify_candlestick(df.iloc[i], df.iloc[i-1], df.iloc[i-2])
            elif i == 1:
                pattern = self.identify_candlestick(df.iloc[i], df.iloc[i-1])
            else:
                pattern = self.identify_candlestick(df.iloc[i])
            candlestick_types.append(pattern)
        df['candlestick_type'] = candlestick_types
        return df
