import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime, timedelta
import pytz

class MT5DataFetcher:
    def __init__(self, timezone='UTC'):
        self.timezone = pytz.timezone(timezone)
        self._initialize_mt5()

    def _initialize_mt5(self):
        if not mt5.initialize():
            raise RuntimeError(f"Failed to initialize MetaTrader 5, error code: {mt5.last_error()}")
        print("MetaTrader 5 initialized.")

    def get_data(self, symbol, timeframe, start_date, end_date):
        # Convert start and end dates to UTC
        start_date_utc = start_date.astimezone(pytz.utc)
        end_date_utc = end_date.astimezone(pytz.utc)

        # Fetch data
        candles = mt5.copy_rates_range(symbol, timeframe, start_date_utc, end_date_utc)

        # Check if data is available
        if candles.size <= 0:
            print("No data available for the specified time range.")
            return None

        # Create a DataFrame from the obtained data
        df = pd.DataFrame(candles, columns=['time', 'open', 'high', 'low', 'close', 'tick_volume', 'spread', 'real_volume'])
        # Convert timestamp to datetime and local timezone
        df['time'] = pd.to_datetime(df['time'], unit='s', utc=True).dt.tz_convert(self.timezone)
        df.set_index('time', inplace=True)

        return df
    
    def get_live_data(self, symbol, timeframe, numCandles):
        bars = mt5.copy_rates_from_pos(symbol, timeframe, 1, numCandles)
        # Create a DataFrame from the obtained data
        currentBars = pd.DataFrame(bars, columns=['time', 'open', 'high', 'low', 'close', 'tick_volume', 'spread', 'real_volume'])
        # Convert timestamp to datetime and local timezone
        currentBars['time'] = pd.to_datetime(currentBars['time'], unit='s', utc=True).dt.tz_convert(self.timezone)
        currentBars.set_index('time', inplace=True)
        return currentBars
    

    def shutdown(self):
        mt5.shutdown()
        print("MetaTrader 5 connection shut down.")

# Example usage:
# if __name__ == "__main__":
#     # Define the parameters
#     symbol = "XAUUSDm"
#     timeframe = mt5.TIMEFRAME_M5
#     start_date = datetime(2024, 5, 1, 12, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))
#     end_date = datetime(2024, 5, 31, 15, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))

#     # Create an instance of the data fetcher
#     fetcher = MT5DataFetcher(timezone='Asia/Karachi')

#     # Fetch the data
#     df = fetcher.get_data(symbol, timeframe, start_date, end_date)

#     # Print the fetched data
#     if df is not None:
#         print(df)

#     # Shutdown the MT5 connection
#     fetcher.shutdown()
