

class TradingSignals:
    def __init__(self, df):
        self.df = df

    def calculate_signals(self):
        self.df['signal'] = 0
        last_signal = None
        for i, row in self.df.iterrows():
            if row['close'] > row['50ema']:
                if last_signal != 2:
                    self.df.at[i, 'signal'] = 2
                    last_signal = 2
            elif row['close'] < row['50ema']:
                if last_signal != 1:
                    self.df.at[i, 'signal'] = 1
                    last_signal = 1

    def evaluate_trades(self):
        self.df['trade_result'] = None
        signal_index = self.df[self.df['signal'].isin([1, 2])].index

        for idx in signal_index:
            entry_price = self.df.at[idx, 'close']
            if self.df.at[idx, 'signal'] == 2:  # Buy signal
                stop_loss = entry_price - 2  # Assuming a 1% stop loss
                take_profit = entry_price + 4  # Assuming a 2% take profit
                for j in self.df.index[self.df.index > idx]:
                    if self.df.at[j, 'low'] <= stop_loss:
                        self.df.at[idx, 'trade_result'] = 'loss'
                        break
                    elif self.df.at[j, 'high'] >= take_profit:
                        self.df.at[idx, 'trade_result'] = 'profit'
                        break
            elif self.df.at[idx, 'signal'] == 1:  # Sell signal
                stop_loss = entry_price + 2  # Assuming a 1% stop loss
                take_profit = entry_price - 4  # Assuming a 2% take profit
                for j in self.df.index[self.df.index > idx]:
                    if self.df.at[j, 'high'] >= stop_loss:
                        self.df.at[idx, 'trade_result'] = 'loss'
                        break
                    elif self.df.at[j, 'low'] <= take_profit:
                        self.df.at[idx, 'trade_result'] = 'profit'
                        break

# Example usage:
# if __name__ == "__main__":
#     symbol = "XAUUSDm"
#     timeframe = mt5.TIMEFRAME_M5
#     start_date = datetime(2024, 5, 1, 12, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))
#     end_date = datetime(2024, 5, 31, 15, 0, 0, tzinfo=pytz.timezone('Asia/Karachi'))

#     fetcher = MT5DataFetcher(timezone='Asia/Karachi')
#     df = fetcher.get_data(symbol, timeframe, start_date, end_date)

#     if df is not None:
#         indicator_calculator = IndicatorCalculator(df)
#         indicator_calculator.calculate_ema(50)
#         indicator_calculator.calculate_volume_ma(20)
#         indicator_calculator.check_ema()
#         indicator_calculator.check_volume()

#         candlestick_identifier = CandlestickPatternIdentifier()
#         df = candlestick_identifier.add_candlestick_column(df)

#         trading_bot = TradingBot(df)
#         trading_bot.calculate_signals()
#         trading_bot.evaluate_trades()

#         print(df)

#     fetcher.shutdown()
